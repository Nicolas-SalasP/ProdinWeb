<?php

// Database Constants
define("DB_SERVER", "localhost");
define("DB_USER", "prodinwe_stgo391");
define("DB_PASS", "391stgo.*.");
define("DB_NAME", "prodinwe_sistema1");

?>